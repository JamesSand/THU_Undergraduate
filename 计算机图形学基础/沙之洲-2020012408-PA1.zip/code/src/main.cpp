#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <iostream>

#include "scene_parser.hpp"
#include "image.hpp"
#include "camera.hpp"
#include "group.hpp"
#include "light.hpp"

#include <string>

using namespace std;

int main(int argc, char *argv[]) {
    for (int argNum = 1; argNum < argc; ++argNum) {
        std::cout << "Argument " << argNum << " is: " << argv[argNum] << std::endl;
    }

    if (argc != 3) {
        cout << "Usage: ./bin/PA1 <input scene file> <output bmp file>" << endl;
        return 1;
    }
    string inputFile = argv[1];
    string outputFile = argv[2];  // only bmp is allowed.

    // TODO: Main RayCasting Logic
    // First, parse the scene using SceneParser.
    // Then loop over each pixel in the image, shooting a ray
    // through that pixel and finding its intersection with
    // the scene.  Write the color at the intersection to that
    // pixel in your output image.

    SceneParser parser = SceneParser(inputFile.c_str());
    Group * group = parser.getGroup();
    PerspectiveCamera * camera = parser.getCamera();
    Vector3f background_color = parser.getBackgroundColor();


    int width = camera->getWidth();
    int height = camera->getHeight();
    Image image = Image(width, height);
    for(int i = 0; i < width; i++){
        for (int j = 0; j < height; j++){
            Vector2f point = Vector2f(i, j);
            Ray ray = camera->generateRay(point);
            Hit hit;
            if (group->intersect(ray, hit, 0.0)){
                Vector3f hit_point = ray.pointAtParameter(hit.getT());
                Vector3f pixel_color = Vector3f::ZERO;
                // all light in scence
                for (int k = 0; k < parser.getNumLights(); k++){
                    Light * light = parser.getLight(k);
                    Vector3f dir, color; // light direciton and light color at hit point
                    light->getIllumination(hit_point, dir, color);
                    pixel_color = pixel_color + hit.getMaterial()->Shade(ray, hit, dir, color);
                }
                image.SetPixel(i, j, pixel_color);
            }
            else{
                image.SetPixel(i, j, background_color);
            }
        }
    }
    image.SaveImage(outputFile.c_str());

    cout << "Hello! Computer Graphics!" << endl;
    return 0;
}

