#ifndef SPHERE_H
#define SPHERE_H

#include "object3d.hpp"
#include <vecmath.h>
#include <cmath>

// TODO: Implement functions and add more fields as necessary

class Sphere : public Object3D {
public:
    Sphere() {
        // unit ball at the center
        sphere_center = Vector3f(0, 0, 0);
        sphere_radius = 1;
    }

    Sphere(const Vector3f &center, float radius, Material *material) : Object3D(material) {
        // 
        sphere_center = center;
        sphere_radius = radius;
    }

    ~Sphere() override = default;

    bool intersect(const Ray &r_const, Hit &h, float tmin) override {
        //
        // normalize ray
        float ray_length = r_const.getDirection().length();
        Ray r = Ray(r_const.getOrigin(), r_const.getDirection().normalized());
        Vector3f l = sphere_center - r.getOrigin();
        float l_length = l.length();
        float t_p = l.dot(l, r.getDirection());

        float d;
        if ( l_length * l_length - t_p * t_p > 0 ){
            d = sqrt(l_length * l_length - t_p * t_p);
        } else {
            d = 0.0;
        }

        if ( d > sphere_radius){
            return false;
        }

        float t_prime;
        if (sphere_radius * sphere_radius - d * d > 0){
            t_prime = sqrt(sphere_radius * sphere_radius - d * d);
        } else {
            t_prime = 0.0;
        }

        if (l_length <= sphere_radius){
            // rayo inside
            float current_t = t_p + t_prime;
            Vector3f intersect_point = r.getOrigin() + current_t * r.getDirection();
            float ratio = current_t / ray_length;
            if ((tmin <= ratio) && (ratio <= h.getT())){
                h.set(ratio, this->material, (sphere_center - intersect_point).normalized());
                return true;
            }else{
                return false;
            }
        }else{
            // rayo outside
            if ( t_p < 0){
                return false;
            }
            float current_t = t_p - t_prime;
            Vector3f intersect_point = r.getOrigin() + current_t * r.getDirection();
            float ratio = current_t / ray_length;
            if ((tmin <= ratio) && (ratio <= h.getT())){
                h.set(ratio, this->material, (intersect_point - sphere_center).normalized());
                return true;
            }else{
                return false;
            }
        }
           
        assert(false);
        return false;
    }

protected:
    Vector3f sphere_center;
    float sphere_radius;
};


#endif
