#ifndef PLANE_H
#define PLANE_H

#include "object3d.hpp"
#include <vecmath.h>
#include <cmath>

// TODO (PA2): Copy from PA1

class Plane : public Object3D {
public:
    Plane() {

    }

    Plane(const Vector3f &normal, float _d, Material *m) : Object3D(m) {
        norm = normal.normalized();
        d = _d;
    }

    ~Plane() override = default;

    bool intersect(const Ray &r_const, Hit &h, float tmin) override {
        // normalize ray
        float ray_length = r_const.getDirection().length();
        Ray r = Ray(r_const.getOrigin(), r_const.getDirection().normalized());
        Vector3f ray_o = r.getOrigin();
        Vector3f ray_d = r.getDirection();
        float current_t = (d - norm.dot(norm, ray_o)) / norm.dot(norm, ray_d);
        if (current_t < 0){
            return false;
        }
        float ratio = current_t / ray_length;
        if ((tmin <= ratio) && (ratio <= h.getT())){
            if (norm.dot(norm, ray_d) < 0){
                h.set(ratio, this->material, norm);
            } else {
                h.set(ratio, this->material, -1 * norm);
            }
            return true;
        }else{
            return false;
        }

        assert(false);
        return false;
    }

    void drawGL() override {
        Object3D::drawGL();
        Vector3f xAxis = Vector3f::RIGHT;
        Vector3f yAxis = Vector3f::cross(norm, xAxis);
        xAxis = Vector3f::cross(yAxis, norm);
        const float planeSize = 10.0;
        glBegin(GL_TRIANGLES);
        glNormal3fv(norm);
        glVertex3fv(d * norm + planeSize * xAxis + planeSize * yAxis);
        glVertex3fv(d * norm - planeSize * xAxis - planeSize * yAxis);
        glVertex3fv(d * norm + planeSize * xAxis - planeSize * yAxis);
        glNormal3fv(norm);
        glVertex3fv(d * norm + planeSize * xAxis + planeSize * yAxis);
        glVertex3fv(d * norm - planeSize * xAxis + planeSize * yAxis);
        glVertex3fv(d * norm - planeSize * xAxis - planeSize * yAxis);
        glEnd();
    }

protected:
    Vector3f norm;
    float d;

};

#endif //PLANE_H
		

