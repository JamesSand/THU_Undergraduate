#ifndef CURVE_HPP
#define CURVE_HPP

#include "object3d.hpp"
#include <vecmath.h>
#include <vector>
#include <utility>

#include <algorithm>

// TODO (PA2): Implement Bernstein class to compute spline basis function.
//       You may refer to the python-script for implementation.

// The CurvePoint object stores information about a point on a curve
// after it has been tesselated: the vertex (V) and the tangent (T)
// It is the responsiblility of functions that create these objects to fill in all the data.
struct CurvePoint {
    Vector3f V; // Vertex
    Vector3f T; // Tangent  (unit)
};

class Curve : public Object3D {
protected:
    std::vector<Vector3f> controls;
public:
    explicit Curve(std::vector<Vector3f> points) : controls(std::move(points)) {}

    bool intersect(const Ray &r, Hit &h, float tmin) override {
        return false;
    }

    std::vector<Vector3f> &getControls() {
        return controls;
    }

    virtual void discretize(int resolution, std::vector<CurvePoint>& data) = 0;

    void drawGL() override {
        Object3D::drawGL();
        glPushAttrib(GL_ALL_ATTRIB_BITS);
        glDisable(GL_LIGHTING);
        glColor3f(1, 1, 0);
        glBegin(GL_LINE_STRIP);
        for (auto & control : controls) { glVertex3fv(control); }
        glEnd();
        glPointSize(4);
        glBegin(GL_POINTS);
        for (auto & control : controls) { glVertex3fv(control); }
        glEnd();
        std::vector<CurvePoint> sampledPoints;
        discretize(30, sampledPoints);
        glColor3f(1, 1, 1);
        glBegin(GL_LINE_STRIP);
        for (auto & cp : sampledPoints) { glVertex3fv(cp.V); }
        glEnd();
        glPopAttrib();
    }
};

enum DrawType {
    Bezier,
    Bspline
};

class Bernstein {
    public:
        DrawType type;
        int n;
        int k;
        float * knot;

        Bernstein(int _n, int _k, DrawType _type){
            n = _n;
            k = _k;
            type = _type;
            knot = new float[n + k + 1];
            if(type == Bezier){
                assert(n == (k + 1));
                for(int i = 0; i < n; i++){
                    knot[i] = 0.0;
                }
                for(int i = n; i < n + k + 1; i++){
                    knot[i] = 1.0;
                }
            }else if(type == Bspline){
                for(int i = 0; i < n + k; i++){
                    knot[i] = float(i) / (n + k);
                }
            }else{
                assert(false);
            }
        }
        ~Bernstein(){
            delete[] knot;
        }

        float get_knot_pad(int index){
            if(index >= 0 && index < (n + k + 1)){
                return knot[index];
            }else if(index >= (n + k + 1) && index < (n + 2 * k + 1)){
                return knot[n + k];
            }
            else{
                assert(false);
            }
        }

        int get_valid_range(float * t_range, int resolution){
            if (type == Bezier){
                for(int i = 0; i < resolution; i++){
                    t_range[i] = float(i) / resolution;
                }
                t_range[resolution] = 1.0;
                return resolution + 1;
            }else if (type == Bspline){
                float step = 1.0 / (float(n + k) * resolution);
                int count = 0;
                for (int i = k; i < n; i++){
                    for(int j = 0; j < resolution; j++){
                        t_range[count] = knot[i] + j * step;
                        count += 1;
                    }
                }
                t_range[count] = knot[n];
                assert(count == (n - k) * resolution);
                return (n - k) * resolution + 1;
            }else{
                assert(false);
            }
        }

        int get_bpos(float mu){
            // check validation
            assert((mu >= knot[0]) && (mu <= knot[n + k]));
            int max_index = -1;
            for(int i = 0; i < n; i++){
                if(mu >= knot[i]){
                    max_index = i;
                }else{
                    break;
                }
            }
            return max_index;
        }

        int get_coeffcient(float * pt, float * dpt, float mu){
            int bpos = get_bpos(mu);
            // init
            for(int i = 0; i < k + 2; i++){
                pt[i] = 0.0;
            }
            pt[k] = 1.0;
            for(int i = 0; i < k + 1; i++){
                dpt[i] = 1.0;
            }

            for (int p = 1; p < k + 1; p++){
                for (int ii = k - p; ii < k + 1; ii++){
                    float w1, dw1;
                    float w2, dw2;
                    int i = ii + bpos - k;
                    if (get_knot_pad(i + p) == get_knot_pad(i)){
                        w1 = mu;
                        dw1 = 1.0;
                    }else{
                        w1 = (mu - get_knot_pad(i)) / (get_knot_pad(i + p) - get_knot_pad(i));
                        dw1 = 1.0 / (get_knot_pad(i + p) - get_knot_pad(i));
                    }

                    if (get_knot_pad(i + p + 1) == get_knot_pad(i + 1)){
                        w2 = 1 - mu;
                        dw2 = -1.0;
                    }else{
                        w2 = (get_knot_pad(i + p + 1) - mu) / (get_knot_pad(i + p + 1) - get_knot_pad(i + 1));
                        dw2 = -1.0 / (get_knot_pad(i + p + 1) - get_knot_pad(i + 1));
                    }

                    if (p == k){
                        dpt[ii] = (dw1 * pt[ii] + dw2 * pt[ii + 1]) * p;
                    }
                        
                    pt[ii] = w1 * pt[ii] + w2 * pt[ii + 1];
                }
            }

            int lsk = bpos - k;
            int rsk = n - bpos -1;
            assert(lsk >= 0 && rsk >= 0);
            return lsk;
        }
};
class BezierCurve : public Curve {
public:
    explicit BezierCurve(const std::vector<Vector3f> &points) : Curve(points) {
        if (points.size() < 4 || points.size() % 3 != 1) {
            printf("Number of control points of BezierCurve must be 3n+1!\n");
            exit(0);
        }
    }

    void discretize(int resolution, std::vector<CurvePoint>& data) override {
        data.clear();
        // TODO (PA2): fill in data vector
        DrawType mode = Bezier;
        int n = controls.size();
        int k = n - 1;
        Bernstein bernstein = Bernstein(n, k, mode);
        float * t_range = new float[(n - k) * resolution + 1];

        int trange_valid_len = bernstein.get_valid_range(t_range, resolution);
        for(int i = 0; i < trange_valid_len; i++){
            float * pt = new float[k + 2];
            float * dpt = new float[k + 1];
            int lsk = bernstein.get_coeffcient(pt, dpt, t_range[i]);

            CurvePoint curr;
            curr.V = Vector3f(0.0, 0.0, 0.0);
            curr.T = Vector3f(0.0, 0.0, 0.0);

            for(int j = lsk; j <= lsk + n - 1; j++){
                curr.V = curr.V + pt[j - lsk] * controls[j];
                curr.T = curr.T + dpt[j - lsk] * controls[j];
            }

            curr.T.normalize();
            data.push_back(curr);

            delete[] pt;
            delete[] dpt;
        }
        delete[] t_range;
    }

protected:

};

class BsplineCurve : public Curve {
public:
    BsplineCurve(const std::vector<Vector3f> &points) : Curve(points) {
        if (points.size() < 4) {
            printf("Number of control points of BspineCurve must be more than 4!\n");
            exit(0);
        }
    }

    void discretize(int resolution, std::vector<CurvePoint>& data) override {
        data.clear();
        // TODO (PA2): fill in data vector

        DrawType mode = Bspline;
        int n = controls.size();
        int k = 3;
        Bernstein b(n, k, mode);
        float * t_range = new float[(n - k) * resolution + 1];
        int t_valid_range_len = b.get_valid_range(t_range, resolution);

        for(int i = 0; i < t_valid_range_len; i++){
            float * pt = new float[k + 2];
            float *dpt = new float[k + 1];
            int lsk = b.get_coeffcient(pt, dpt, t_range[i]);

            CurvePoint curr;
            curr.T = Vector3f(0.0, 0.0, 0.0);
            curr.V = Vector3f(0.0, 0.0, 0.0);

            for(int j = lsk; j <= lsk + 3; j++){
                curr.V = curr.V + pt[j - lsk] * controls[j];
                curr.T = curr.T + dpt[j - lsk] * controls[j];
            }

            curr.T.normalize();
            data.push_back(curr);
            delete[] pt;
            delete[] dpt;  
        }
        delete[] t_range;
    }

protected:

};

#endif // CURVE_HPP
