#pragma once

#include <image.hpp>
#include <algorithm>
#include <queue>
#include <cstdio>

class Element {
public:
    virtual void draw(Image &img) = 0;
    virtual ~Element() = default;
};

class Line : public Element {

public:
    int xA, yA;
    int xB, yB;
    Vector3f color;
    void draw(Image &img) override {
        // TODO: Implement Bresenham Algorithm

        printf("Draw a line from (%d, %d) to (%d, %d) using color (%f, %f, %f)\n", xA, yA, xB, yB,
                color.x(), color.y(), color.z());

        if (xA == xB){ // horizontal
            for (int i = yA; i <= yB; i++){
                img.SetPixel(xA, i, color);
            }
            return;
        }

        if (yA == yB){ // vertical
            for (int i = xA; i <= xB; i++){
                img.SetPixel(i, yA, color);
            }
            return;
        }

        // 0<k<=1
        if (((xA < xB) && (yA < yB) && ((xB - xA) >= (yB - yA))) || ((xB < xA) && (yB < yA) && ((xA - xB) >= (yA - yB)))){ 
            int dx = (xB - xA) > 0 ? (xB - xA) : (xA - xB);
            int dy = (yB - yA) > 0 ? (yB - yA) : (yA - yB);
            int e = -dx;
            int x = xA < xB ? xA : xB;
            int y = yA < yB ? yA : yB;
            for (int i = 0; i <= dx; i++){
                img.SetPixel(x++, y, color);
                e = e + 2 * dy;
                if (e >= 0){
                    y++;
                    e -= 2 * dx;
                }
            }
            return;
        }

        // 1<k
        if (((xA < xB) && (yA < yB) && ((xB - xA) < (yB - yA))) || ((xB < xA) && (yB < yA) && ((xA - xB) < (yA - yB)))){
            int dx = (xB - xA) > 0 ? (xB - xA) : (xA - xB);
            int dy = (yB - yA) > 0 ? (yB - yA) : (yA - yB);
            int e = -dy;
            int x = xA < xB ? xA : xB;
            int y = yA < yB ? yA : yB;
            for (int i = 0; i <= dy; i++){
                img.SetPixel(x, y++, color);
                e = e + 2 * dx;
                if (e >= 0)
                {
                    x++;
                    e -= 2 * dy;
                }
            }
            return;
        }

        //-1>=k>0
        if (((xA < xB) && (yB < yA) && ((xB - xA) >= (yA - yB))) || ((xB < xA) && (yA < yB) && ((xA - xB) >= (yB - yA)))){
            int dx = (xB - xA) > 0 ? (xB - xA) : (xA - xB);
            int dy = (yB - yA) > 0 ? (yB - yA) : (yA - yB);
            int e = -dx;
            int x = xA < xB ? xA : xB;
            int y = yA < yB ? yB : yA;
            for (int i = 0; i <= dx; i++){
                img.SetPixel(x++, y, color);
                e = e + 2 * dy;
                if (e >= 0){
                    y--;
                    e -= 2 * dx;
                }
            }
            return;
        }

        // k<-1
        int dx = (xB - xA) > 0 ? (xB - xA) : (xA - xB);
        int dy = (yB - yA) > 0 ? (yB - yA) : (yA - yB);
        int e = -dy;
        int x = xA < xB ? xB : xA; //从右下点开始绘制
        int y = yA < yB ? yA : yB;
        for (int i = 0; i <= dy; i++)
        {
            img.SetPixel(x, y++, color);
            e = e + 2 * dx;
            if (e >= 0)
            {
                x--;
                e -= 2 * dy;
            }
        }
        return;
    }
};

class Circle : public Element {

public:
    int cx, cy;
    int radius;
    Vector3f color;

    void CirclePoints(Image &img, int x, int y, Vector3f color_){
        img.SetPixel(x + cx, y + cy, color_);
        img.SetPixel(y + cx, x + cy, color_);
        img.SetPixel(-x + cx, y + cy, color_);
        img.SetPixel(y + cx, -x + cy, color_);
        img.SetPixel(x + cx, -y + cy, color_);
        img.SetPixel(-y + cx, x + cy, color_);
        img.SetPixel(-x + cx, -y + cy, color_);
        img.SetPixel(-y + cx, -x + cy, color_);
    }

    void draw(Image &img) override {
        // TODO: Implement Algorithm to draw a Circle

        printf("Draw a circle with center (%d, %d) and radius %d using color (%f, %f, %f)\n", cx, cy, radius,
               color.x(), color.y(), color.z());

        int x_co = 0;
        int y_co = radius;
        //实际绘制的时候x_co和y_co还要加上圆心的偏置
        int t = 5 - 4 * radius;
        CirclePoints(img, x_co, y_co, color);
        while (x_co <= y_co){
            if (t <= 0){
                t += 8 * x_co + 12;
            }else{
                t += 8 * (x_co - y_co) + 20;
                y_co--;
            }
            x_co++;
            CirclePoints(img, x_co, y_co, color);
        }
    }
};

class Fill : public Element {

public:
    int cx, cy;
    Vector3f color;

    bool same_color(const Vector3f &c1, const Vector3f &c2){
        return (c1.x() == c2.x()) && (c1.y() == c2.y()) && (c1.z() == c2.z());
    }

    bool valid_coord(Image& img, int x, int y){
        int img_width = img.Width();
        int img_height = img.Height();

        return x >= 0 && x < img_width && y >= 0 && y < img_height;
    }

    void draw(Image &img) override {
        // TODO: Flood fill

        printf("Flood fill source point = (%d, %d) using color (%f, %f, %f)\n", cx, cy,
                color.x(), color.y(), color.z());

        Vector3f old_color = img.GetPixel(cx, cy);
        std::queue<int> q_x;
        std::queue<int> q_y;
        q_x.push(cx);
        q_y.push(cy);
        img.SetPixel(cx, cy, color); // change color when enqueue
        int x, y;
        while (!q_x.empty()){
            x = q_x.front();
            y = q_y.front();
            q_x.pop();
            q_y.pop();
            // left
            if (valid_coord(img, x + 1, y) && same_color(img.GetPixel(x + 1, y), old_color)){
                q_x.push(x + 1);
                q_y.push(y);
                img.SetPixel(x + 1, y, color);
            }

            // right
            if (valid_coord(img, x - 1, y) && same_color(img.GetPixel(x - 1, y), old_color)){
                q_x.push(x - 1);
                q_y.push(y);
                img.SetPixel(x - 1, y, color);
            }

            // up
            if (valid_coord(img, x, y + 1) && same_color(img.GetPixel(x, y + 1), old_color)){
                q_x.push(x);
                q_y.push(y + 1);
                img.SetPixel(x, y + 1, color);
            }
            
            // down
            if (valid_coord(img, x, y - 1) && same_color(img.GetPixel(x, y - 1), old_color)){
                q_x.push(x);
                q_y.push(y - 1);
                img.SetPixel(x, y - 1, color);
            }
        }
    }
};